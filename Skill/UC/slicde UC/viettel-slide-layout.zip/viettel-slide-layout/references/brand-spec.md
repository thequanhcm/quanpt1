# Brand Specification — Viettel Networks (VTNet)

Trích xuất từ Brand Guidelines Nhận diện thương hiệu nội bộ Viettel Networks, phiên bản 2025 v1.0.

## 1. Hệ thống Logo

Logo là tài sản thương hiệu quan trọng nhất. Tuân thủ nghiêm ngặt quy tắc sử dụng.

### Phiên bản logo

| Nền | Phiên bản |
|---|---|
| Nền đen / tối | Chữ trắng |
| Nền đỏ Viettel | Nền đặc |
| Nền trắng / sáng | Chữ đen |

### Vùng bảo vệ (Clear Space)

Khoảng trống tối thiểu = ½ chiều cao chữ "V" trên mọi cạnh.

| Ứng dụng | Kích thước tối thiểu | Định dạng |
|---|---|---|
| Digital (web, app) | 80px chiều rộng | PNG, SVG |
| Print (in ấn) | 20mm chiều rộng | PDF, EPS |
| Social media | 120px chiều rộng | PNG 2x |
| Video / Motion | 5% chiều rộng frame | PNG trong suốt |

### Những điều cần tránh với logo

- Không xoay logo
- Không kéo méo, thay đổi tỷ lệ
- Không đổi màu ngoài bảng chính thức
- Không thêm shadow, gradient, outline
- Không tách biểu tượng và tên thương hiệu
- Không đặt trên nền tương phản thấp
- Không dùng logo cũ trước 2020

### QUY TẮC ĐẶC BIỆT CHO SLIDE

**TUYỆT ĐỐI không sử dụng logo Viettel Networks đưa vào các slide.** Logo sẽ được người dùng thêm qua slide master hoặc template riêng.

## 2. Hệ thống Màu sắc

### Màu chính — Viettel Red

| Thuộc tính | Giá trị |
|---|---|
| HEX | **#E30613** (brand chính) / **#EE0033** (slide, digital) |
| RGB | 227 · 6 · 19 |
| CMYK | C0 M100 Y92 K0 |
| Pantone | 485 C |

**Hướng dẫn sử dụng đỏ Viettel:**
- Tiêu đề nổi bật, CTA, nút chính
- Đường kẻ nhấn mạnh (accent bar)
- Icon và yếu tố interactive
- **Không dùng làm màu nền lớn quá 30%**
- Ưu tiên kết hợp với Black và White

### Bảng màu đầy đủ

| Tên | HEX | Sử dụng |
|---|---|---|
| **Viettel Red** | #EE0033 | Màu chủ đạo · CTA · Tiêu đề · Icon · Header bảng |
| **Red Dark** | #B30000 | Hover state · Tiêu đề đậm · Sub-header bảng |
| **Red Light** | #FF2D2D | Accent nhẹ · Highlight (KHÔNG dùng cho text trên nền trắng — fail WCAG) |
| **Black** | #0A0A0A | Text chính trên nền sáng · **KHÔNG dùng làm nền slide/card** |
| **Dark** | #1A1A1A | Surface text · Nội dung đậm |
| **Gray 1** | #4A4A4A | Văn bản thân · Icon phụ |
| **Gray 2** | #7F7F7F | Placeholder · Label · Metadata |
| **Gray 3** | #CCCCCC | Đường kẻ · Divider · Viền bảng |
| **Gray 4** | #F5F5F5 | Nền card · Background nhẹ · Hàng xen kẽ bảng |
| **White** | #FFFFFF | Nền slide chính |

### QUY TẮC NỀN — BẮT BUỘC

**TUYỆT ĐỐI không sử dụng các màu tối, màu đen làm nền Slide hoặc nền các thẻ Card.**
Luôn ưu tiên nền sáng: trắng #FFFFFF, xám nhạt #F5F5F5.

### Accessibility — Tương phản WCAG 2.1

| Cặp màu | Tỷ lệ | WCAG | Ghi chú |
|---|---|---|---|
| Đỏ #EE0033 / Trắng | 4.5:1 | ✓ AA | Dùng cho text ≥ 14px bold |
| Trắng / Đen #0A0A0A | 21:1 | ✓ AAA | Tối ưu |
| Gray 1 / Trắng | 9.7:1 | ✓ AAA | Văn bản thân |
| Gray 2 / Trắng | 4.1:1 | ⚠ AA large | Chỉ text ≥ 18px |
| Red Light / Trắng | 2.8:1 | ✗ Fail | KHÔNG dùng cho text |

## 3. Hệ thống Typography

### Font chính — FS Magistral

Sử dụng cho: Tiêu đề, Logo text, Display, Heading H1-H3, Số liệu lớn.

| Weight | Giá trị | Dùng cho |
|---|---|---|
| Light (300) | Nội dung nhẹ, phụ đề |
| Book (400) | Thân văn bản tiêu đề |
| Medium (500) | Nhấn mạnh nhẹ |
| **Bold (700)** | Tiêu đề chính |
| **ExtraBold (800)** | Hero, Cover, Display |

### Font phụ — PF BeauSans Pro

Sử dụng cho: Body text, tài liệu đối ngoại, subheading, caption, UI text.

| Weight | Giá trị | Dùng cho |
|---|---|---|
| Light (300) | Body dài, đọc nhiều |
| Regular (400) | Body tiêu chuẩn |
| SemiBold (600) | Nhấn mạnh |
| Bold (700) | Header nhỏ |

### Font hỗ trợ — Roboto

Sử dụng cho: UI digital, số liệu, bảng biểu, monospace data, fallback hệ thống.

Fallback chain: Roboto → Arial → Helvetica Neue

### Type Scale cho Slide

| Cấp độ | Font | Cỡ | Weight | Ứng dụng |
|---|---|---|---|---|
| **Display / Hero** | FS Magistral | 56-72px | ExtraBold 800 | Bìa, hero section |
| **Heading 1** | FS Magistral | 40px | Bold 700 | Tiêu đề slide |
| **Heading 2** | FS Magistral | 32px | Bold 700 | Tiêu đề section |
| **Heading 3** | FS Magistral | 24px | Medium 500 | Tiêu đề phụ |
| **Body** | PF BeauSans Pro | 16px | Regular 400 | Nội dung đọc |
| **Small Body** | PF BeauSans Pro | 14px | Bbook 350 | Chú thích phụ |
| **Caption / Label** | Roboto | 12px | Medium 500 | Nhãn, metadata |
| **Mono / Data** | Roboto | 13px | Regular 400 | Số liệu, code |

### Quy tắc font cho file docx (dàn trang)

Trong file Word dàn trang, luôn dùng **Arial** làm font thực tế (đảm bảo hiển thị đúng trên mọi máy). Trong phần "Hướng dẫn thiết kế" ghi font Viettel chính thức (FS Magistral, PF BeauSans Pro) kèm fallback Arial.

## 4. Visual Language

### Nguyên tắc thiết kế

| Nguyên tắc | Mô tả |
|---|---|
| **Bold** | Font nặng, màu tương phản cao, yếu tố lớn |
| **Clean** | Khoảng trắng đủ, bố cục đơn giản |
| **Purposeful** | Mỗi yếu tố có mục đích rõ ràng |
| **Precision** | Grid 8px, spacing nhất quán |

### Spacing — Grid 8px

| Token | Value | Ứng dụng |
|---|---|---|
| xs | 4px | Icon-label gap |
| sm | 8px | Padding nhỏ |
| md | 16px | Padding chuẩn |
| lg | 24px | Gutter grid |
| xl | 32px | Spacing giữa nhóm |
| 2xl | 48px | Padding section |
| 3xl | 64px | Spacing sections |

## 5. Quy tắc thiết kế Slide — Từ file Hướng dẫn thiết kế

### Tiêu đề slide

- Nhấn mạnh bằng đỏ Viettel **#EE0033** — đồng nhất 1 màu cho TOÀN BỘ slide
- Chữ **IN HOA**
- Tất cả tiêu đề cùng **1 font, 1 cỡ chữ, 1 màu**, căn giữa
- Sử dụng đúng tiêu đề đã đặt cho mỗi slide

### Nội dung

- Dựa 100% trên nội dung nguồn — **không tự bịa**
- Trình bày súc tích, dễ hiểu
- Đơn giản hóa dữ liệu phức tạp
- Bullet thiết kế ấn tượng cho nhiều ý nhỏ
- Size chữ **lớn nhất có thể** phù hợp bố cục

### Đồ họa & Icon

- Icon, hình minh họa chất lượng cao, phong cách 2D/3D Viettel
- Hình ảnh liên quan trực tiếp nội dung
- **TUYỆT ĐỐI không nền đen/tối cho card**
- **TUYỆT ĐỐI không logo Viettel Networks trên slide**

### Layout nâng cao

- Mỗi slide **layout khác nhau** — không lặp
- Đa dạng: 2-3 cột, block/card, so sánh, phân tầng, highlight box
- Mỗi ý chính có icon
- Ít nhất 1 hình ảnh minh họa mỗi slide (trừ slide bảng dữ liệu)
- Ưu tiên bullet ngắn, từ khóa nổi bật, highlight keyword
- Thiết kế sạch, hiện đại, khoảng trắng lớn

### Kết quả mong muốn

- Font lớn — đọc rõ từ xa
- Thiết kế đa dạng — không đơn điệu
- Có icon + hình ảnh đầy đủ
- Phong cách chuyên nghiệp — cấp lãnh đạo
