# Design Rules — Dàn trang Slide Viettel Networks

Quy tắc thiết kế chi tiết khi dàn trang slide, bao gồm layout patterns, workflow xử lý từng loại tài liệu nguồn, và mẫu hướng dẫn thiết kế cho từng kiểu slide.

## 1. Layout Patterns cho từng kiểu slide

### COVER — Trang tiêu đề

```
┌────────────────────────────────────────┐
│                                        │
│         [Tên đơn vị — xám]            │
│                                        │
│   ════ accent bar đỏ #EE0033 ════     │
│                                        │
│     TIÊU ĐỀ LỚN (đỏ, in hoa)        │
│     Phụ đề (đen, nhỏ hơn)            │
│                                        │
│     Thông tin: tác giả, phiên bản     │
│                                        │
│              Ngày tháng                │
│                                        │
│  [Có thể: hình abstract 10% opacity]  │
└────────────────────────────────────────┘
```

**Hướng dẫn mẫu:**
- Bố cục: Full-screen, tiêu đề 40% trung tâm, căn giữa
- Màu: Nền trắng. Tiêu đề đỏ #EE0033. Phụ đề đen #0A0A0A
- Font: Tiêu đề FS Magistral ExtraBold 56px / Arial Bold 40pt
- Hình ảnh: Accent bar đỏ ngang 30% slide. Tùy chọn hình abstract góc dưới
- Ghi chú: Tối giản, trang trọng, không nhồi thông tin

### OUTLINE — Slide tổng quan phần

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ PHẦN (đỏ, căn giữa)        │
│                                        │
│  ┌─── ① Block 1 ──────────────────┐   │
│  │  Viền trái đỏ                   │   │
│  │  Tiêu đề + danh sách nội dung  │   │
│  └─────────────────────────────────┘   │
│  ┌─── ② Block 2 ──────────────────┐   │
│  │  Viền trái đỏ                   │   │
│  │  Tiêu đề + danh sách nội dung  │   │
│  └─────────────────────────────────┘   │
│  ┌─── ③ Block 3 ──────────────────┐   │
│  │  Viền trái đỏ                   │   │
│  │  Tiêu đề + danh sách nội dung  │   │
│  └─────────────────────────────────┘   │
└────────────────────────────────────────┘
```

**Hướng dẫn mẫu:**
- Bố cục: Danh sách dọc, mỗi mục là card có viền trái đỏ 4px
- Màu: Số thứ tự trong vòng tròn đỏ #EE0033 chữ trắng
- Font: Tên mục Bold 18px, chi tiết Regular 14px
- Ghi chú: Slide này chỉ để overview, không chi tiết nội dung

### CONTENT_TEXT — Nội dung bullet/text

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ (đỏ, căn giữa)             │
│                                        │
│  ┌──────────60%──────┐ ┌───40%────┐   │
│  │ • Bullet 1        │ │          │   │
│  │ • Bullet 2        │ │  [Hình]  │   │
│  │ • Bullet 3        │ │          │   │
│  │ • Bullet 4        │ │          │   │
│  └───────────────────┘ └──────────┘   │
│                                        │
│  ╔══ Highlight box (nếu có) ════════╗ │
│  ╚══════════════════════════════════╝ │
└────────────────────────────────────────┘
```

### CONTENT_STEPS — Quy trình/bước

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ (đỏ, căn giữa)             │
│                                        │
│  ① ──→ ② ──→ ③ ──→ ④               │
│  Card   Card   Card   Card            │
│  Mô tả Mô tả  Mô tả  Mô tả          │
│                                        │
│  hoặc dạng timeline dọc:              │
│  ① Bước 1 — mô tả                    │
│  │                                     │
│  ② Bước 2 — mô tả                    │
│  │                                     │
│  ③ Bước 3 — mô tả                    │
└────────────────────────────────────────┘
```

### CONTENT_COMPARE — So sánh

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ (đỏ, căn giữa)             │
│                                        │
│  ┌──── Cột A ────┐ ┌──── Cột B ────┐ │
│  │ Header (đỏ)    │ │ Header (xám)   │ │
│  │ • Nội dung 1   │ │ • Nội dung 1   │ │
│  │ • Nội dung 2   │ │ • Nội dung 2   │ │
│  │ ✅ Ưu điểm     │ │ ⚠️ Hạn chế     │ │
│  └────────────────┘ └────────────────┘ │
└────────────────────────────────────────┘
```

### CONTENT_TABLE — Bảng dữ liệu

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ (đỏ, căn giữa)             │
│                                        │
│  ┌──────────────────────────────────┐  │
│  │ Header (nền đỏ #EE0033, trắng)  │  │
│  ├──────────────────────────────────┤  │
│  │ Sub-header (nền #CC0029, trắng) │  │
│  ├──────────────────────────────────┤  │
│  │ Data row 1 (nền trắng)          │  │
│  │ Data row 2 (nền xám #F5F5F5)    │  │
│  │ Data row 3 (nền trắng)          │  │
│  └──────────────────────────────────┘  │
│                                        │
│  * Số liệu nổi bật: đỏ #EE0033 bold  │
└────────────────────────────────────────┘
```

### CONTENT_GRID — Grid cards

```
┌────────────────────────────────────────┐
│  TIÊU ĐỀ (đỏ, căn giữa)             │
│                                        │
│  ┌─Card─┐ ┌─Card─┐ ┌─Card─┐          │
│  │ Icon │ │ Icon │ │ Icon │          │
│  │ Title│ │ Title│ │ Title│          │
│  │ Desc │ │ Desc │ │ Desc │          │
│  └──────┘ └──────┘ └──────┘          │
│  ┌─Card─┐ ┌─Card─┐ ┌─Card─┐          │
│  │ Icon │ │ Icon │ │ Icon │          │
│  │ Title│ │ Title│ │ Title│          │
│  │ Desc │ │ Desc │ │ Desc │          │
│  └──────┘ └──────┘ └──────┘          │
└────────────────────────────────────────┘
```

### CLOSING — Trang kết

```
┌────────────────────────────────────────┐
│                                        │
│                                        │
│     TRÂN TRỌNG CẢM ƠN!               │
│     (đỏ #EE0033, in hoa, 56px)        │
│                                        │
│   ════ accent bar đỏ ════             │
│                                        │
│     Tên đơn vị                        │
│     Thông tin liên hệ                 │
│                                        │
│              Năm                       │
│                                        │
└────────────────────────────────────────┘
```

## 2. Workflow xử lý từng loại nguồn

### Tài liệu dài (Word/PDF > 10 trang)

1. Đọc toàn bộ → liệt kê heading H1/H2/H3
2. Mỗi H1 → 1 slide Outline + nhiều slide nội dung
3. Mỗi H2 → 1 slide nội dung (hoặc gộp 2-3 H2 nếu ngắn)
4. H3 → bullet trong slide H2 cha
5. Slide đầu = Cover, slide cuối = Closing
6. Tổng ước tính: 1 slide / 1-2 trang tài liệu

### Tài liệu ngắn (1-3 trang)

1. Đọc → xác định key messages
2. Dàn thành 1-5 slides nội dung
3. Cover + nội dung + Closing

### Bảng dữ liệu (Excel)

1. Đọc bảng bằng openpyxl → xác định merge cell, cấu trúc
2. **Giữ nguyên 100%** nội dung, cấu trúc, merge cell
3. Tính toán column widths tỉ lệ với bảng gốc
4. Header: nền đỏ #EE0033
5. Nội dung dài trong ô → bullet với label bold đỏ
6. Số liệu quan trọng → đỏ bold, cỡ lớn
7. Orientation: Landscape nếu bảng > 6 cột

### Nhiều file đính kèm

1. Đọc tất cả file → hiểu chủ đề chung
2. File Brand Guidelines → trích xuất quy tắc brand
3. File Hướng dẫn thiết kế → áp dụng quy tắc
4. File nội dung → dàn trang thành slides
5. Ưu tiên: nội dung chính từ file nguồn, brand từ guidelines

## 3. Mẫu hướng dẫn thiết kế cho từng thuộc tính

### Bố cục (Layout)

Ghi rõ:
- Kiểu layout: 1 cột / 2 cột (tỉ lệ) / grid (NxM) / timeline / so sánh
- Vị trí tiêu đề: trên cùng, căn giữa / trái
- Vị trí nội dung: vùng chính, tỉ lệ phần trăm
- Vị trí hình ảnh: cột phải / nền / góc
- Element đặc biệt: highlight box, accent bar, banner

**Ví dụ:** "Layout 2 cột. Cột trái (60%): 4 block nội dung xếp dọc, mỗi block có icon + tiêu đề nhỏ + mô tả. Cột phải (40%): hình minh họa."

### Màu sắc

Ghi rõ HEX cho MỌI element:
- Nền slide: #FFFFFF (luôn sáng)
- Nền card/block: #FFFFFF hoặc #F5F5F5 (luôn sáng)
- Tiêu đề: đỏ #EE0033
- Nội dung: đen #0A0A0A hoặc xám #4A4A4A
- Header bảng: nền đỏ #EE0033, chữ trắng
- Viền: xám #CCCCCC
- Highlight: đỏ #EE0033 bold
- Icon: đỏ #EE0033

**Ví dụ:** "Nền trắng #FFFFFF. Tiêu đề đỏ #EE0033 căn giữa. Card: nền #F5F5F5, viền #CCCCCC, shadow nhẹ. Số liệu nổi bật: đỏ #EE0033 bold 20pt."

### Font chữ

Ghi rõ cho mỗi element: font + size + weight + color + alignment

**Ví dụ:** "Tiêu đề: FS Magistral Bold 40px / fallback Arial Bold 28pt, in hoa, đỏ #EE0033, căn giữa. Nội dung: PF BeauSans Pro Regular 14px / Arial 12pt, đen #0A0A0A."

### Hình ảnh / Icon / Biểu đồ

- Gợi ý cụ thể icon phù hợp nội dung (dùng emoji hoặc mô tả)
- Kiểu hình: flat 2D, isometric, photo, wireframe
- Placeholder cho screenshot nếu hướng dẫn step-by-step
- Biểu đồ: loại (cột/tròn/đường), dữ liệu highlight
- Quy tắc: không dùng ảnh trang trí vô nghĩa

**Ví dụ:** "Icon: 📡 (di động), ⛓️ (xâu chuỗi), 📊 (đánh giá). Hình minh họa: mockup giao diện tool, phong cách flat 2D tông đỏ-trắng."

### Ghi chú trình bày

- Key message người thuyết trình cần nhấn mạnh
- Thứ tự nhấn: điểm 1, điểm 2, điểm 3
- Số liệu cần highlight bằng giọng
- Câu hỏi tương tác với khán giả (nếu phù hợp)
- Thời gian ước tính cho slide

**Ví dụ:** "Nhấn mạnh: (1) Giảm từ 5 chuỗi → 2 chuỗi, (2) 80% tổng cảnh báo cả năm, (3) Gộp 194 cảnh báo đơn → giảm noise."

## 4. Quy tắc docx-js cho file Word dàn trang

### Cấu hình trang

| Tình huống | Orientation | Page size | Margin |
|---|---|---|---|
| Nhiều slide, text-heavy | Portrait A4 | 11906 x 16838 DXA | 1440 (1 inch) |
| Bảng rộng > 6 cột | Landscape A4 | swap + LANDSCAPE | 720-1000 |
| Slide đơn lẻ | Landscape A4 | swap + LANDSCAPE | 720-1000 |

### Header/Footer chuẩn

```
Header: "DÀN TRANG SLIDE — [TÊN TÀI LIỆU]" | "Viettel Networks — Tài liệu nội bộ"
         ═══════ đường đỏ #EE0033 ═══════
         
Footer: "VTNet — [Đơn vị]" | "Trang [N]"
         ─────── đường xám #CCCCCC ───────
```

### Heading styles

- Heading 1: Slide title — 32 size (16pt), bold, đỏ #EE0033
- Heading 2: Section title — 26 size (13pt), bold, đen #0A0A0A
- Body: 22 size (11pt), Arial, xám #4A4A4A

### Bảng hướng dẫn thiết kế

- 2 cột: Thuộc tính (28%) + Chi tiết (72%)
- Header: nền đỏ #EE0033, chữ trắng
- Data rows: xen kẽ trắng / #F5F5F5
- Label thuộc tính: đỏ #EE0033 bold
- Nội dung: đen #1A1A1A regular
- Cell margins: top/bottom 80, left/right 120

### Bảng dữ liệu gốc (từ Excel)

- Header: nền đỏ #EE0033, chữ trắng, bold
- Sub-header: nền #CC0029, chữ trắng, bold
- Viền: xám #CCCCCC, size 4
- Nội dung dài: tách bullet, label bold đỏ
- Merge cell: giữ đúng cấu trúc gốc (rowSpan, columnSpan)
- Số liệu nổi bật: đỏ #EE0033, bold, cỡ lớn hơn body text

## 5. Checklist cuối cùng trước xuất file

### Nội dung
- [ ] Giữ nguyên 100% nội dung từ tài liệu nguồn
- [ ] Không tự bịa hoặc suy diễn thêm
- [ ] Tiếng Việt có dấu đầy đủ, không lỗi chính tả
- [ ] Có slide Outline trước mỗi phần lớn (H1)
- [ ] Slide đầu = Cover, slide cuối = "TRÂN TRỌNG CẢM ƠN!"

### Thiết kế
- [ ] Mỗi slide có đủ 3 phần: tiêu đề + nội dung + hướng dẫn thiết kế
- [ ] Hướng dẫn thiết kế có đủ 5 thuộc tính
- [ ] Tất cả màu HEX cụ thể (không "màu đỏ" mà "#EE0033")
- [ ] Tất cả tiêu đề cùng font/cỡ/màu đỏ #EE0033, căn giữa, in hoa
- [ ] KHÔNG nền đen/tối cho slide hoặc card
- [ ] KHÔNG logo Viettel Networks trên slide

### Kỹ thuật
- [ ] File validate PASSED (python scripts/office/validate.py)
- [ ] Bảng dữ liệu merge cell đúng cấu trúc gốc
- [ ] Column widths tỉ lệ hợp lý
- [ ] Page orientation phù hợp nội dung
