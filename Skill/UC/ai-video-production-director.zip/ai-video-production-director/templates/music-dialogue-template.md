# Music and Dialogue Production Sheet

## Music Bible

| Theme/motif | BPM/meter | Tonal character | Core instruments | Emotional arc | Forbidden drift |
|---|---|---|---|---|---|

## Master Music Cue Sheet

| Absolute timecode | Scene/beat | Musical action | Intensity | Instrument/stem change | Dialogue ducking | Transition/tail |
|---|---|---|---:|---|---|---|

## Character Voice Bible

| Character ID | Voice profile | Pace | Diction | Emotional range | Fixed reference/settings |
|---|---|---:|---|---|---|

## Dialogue Beat Sheet

| Beat | Timecode | Speaker → Listener | Exact line | Subtext | Speaker action | Listener reaction | Line/reaction sec | Method |
|---|---|---|---|---|---|---|---:|---|

Method: `NATIVE`, `POST-LIPSYNC` or `OFF-SCREEN`.
