# Source Evidence Ledger

| ID | Content | Type | Source/location | Interpretation allowed? |
|---|---|---|---|---|
| F01 |  | Source-backed fact |  | Limited |
| Q01 |  | Verbatim/meaning-locked quote |  | No meaning change |
| C01 |  | AI recommendation | N/A | Yes |
| U01 |  | Unverified | Unknown | Do not use as fact |

# Content Treatment Map
| Source item | Treatment | Production use | Notes |
|---|---|---|---|
|  | KEEP/COMPRESS/VISUALIZE/MOTION GRAPHIC/VOICE/ADD IN POST/OMIT |  |  |
