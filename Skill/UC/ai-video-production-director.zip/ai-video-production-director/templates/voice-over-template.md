# Voice-over

| Scene | Voice text | Words | Target sec | WPM | Emotion | Emphasis | Pauses |
|---|---|---:|---:|---:|---|---|---|
| S01 |  | 0 | 0 | 140 |  |  |  |

Timing formula:
`seconds = word_count / WPM × 60 + pauses`

## Character Voice Bible

| Character | Voice age/timbre | Pace | Diction/accent | Emotional range | Reference/settings |
|---|---|---:|---|---|---|

## Dialogue and Reaction Timing

| Beat | Speaker | Listener | Exact line | Line sec | Reaction/action sec | Total sec | Lip-sync method |
|---|---|---|---|---:|---:|---:|---|
