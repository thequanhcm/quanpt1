# Master Script

## Core Message
...

## Story Arc
Hook → Context → Tension → Transformation → Proof/Impact → Resolution/CTA

| Scene | Timecode | Purpose | Visual/Action | Camera | Voice | Text/Audio | Transition |
|---|---|---|---|---|---|---|---|
| S01 | 00:00–00:00 |  |  |  |  |  |  |

## Dialogue Beat Sheet — when characters speak

| Beat | Timecode | Speaker → Listener | Exact dialogue | Subtext/emotion | Speaker action | Listener reaction | Lip-sync method |
|---|---|---|---|---|---|---|---|
| D01 |  |  |  |  |  |  | POST / NATIVE |

## Music Bible

Theme/motif:

BPM/meter:

Tonal character:

Core instruments:

Emotional arc:

Prohibited drift:

## Music Cue Sheet

| Timecode | Story beat | Music action | Intensity | Dialogue ducking | Transition/tail |
|---|---|---|---:|---|---|
