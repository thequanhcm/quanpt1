# Gemini / Veo Generation Package

| Clip | Duration | Start frame | Gemini/Veo prompt | Constraints | End frame | Handoff |
|---|---:|---|---|---|---|---|
| C01 |  |  |  |  |  |  |

## Prompt skeleton
Duration and aspect ratio:
Mode:
Subject identity:
Environment:
START FRAME:
TEMPORAL ACTION:
CAMERA RESPONSE:
ENVIRONMENT MOTION:
Lighting/color:
Composition/screen direction:
Continuity anchors:
Previous end-state ledger:
Exact start-state reconstruction:
Transition Delta (only allowed changes):
Character blocking and eyelines:
Prop positions, ownership and hand occupancy:
END FRAME:
End-state ledger:
Transition handoff:
Audio intent:
Speaker/listener and exact dialogue timing:
Lip-sync method:
Text strategy:
Negative constraints:
