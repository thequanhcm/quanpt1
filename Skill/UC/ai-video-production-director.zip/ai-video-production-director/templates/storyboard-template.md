# Storyboard / Shot List

| Shot | Timecode | Purpose | Visual | Subject action | Shot/Lens | Camera | Light/Color | Audio | Text strategy | Start frame | End frame |
|---|---|---|---|---|---|---|---|---|---|---|---|
| SH01 |  |  |  |  |  |  |  |  | ADD IN POST |  |  |

## Blocking and Prop State Ledger

| Clip boundary | Entity/Prop ID | Position (L/C/R, FG/MG/BG) | Orientation/eyeline | Pose/action phase | Contact/hand | Condition |
|---|---|---|---|---|---|---|

## Transition Delta

| From → To | Permitted character movement | Permitted prop movement | Continued action | Camera change | Everything else |
|---|---|---|---|---|---|
| C01 → C02 |  |  |  |  | LOCKED |
