# Gemini usage

Gemini environments may not interpret OpenAI/Claude skill metadata identically. Use this package as a portable instruction bundle.

Recommended setup:
1. Use `SKILL.md` as the main system/custom instruction.
2. Make `references/`, `templates/`, and `examples/` available as supporting knowledge files.
3. Keep the relative file names intact.
4. For Veo work, always load `references/gemini-veo.md`, `references/prompt-engineering.md`, and `references/continuity.md`.

Suggested invocation:
`Use the ai-video-production-director instructions. Create a STANDARD production package from the attached source, optimized for Gemini/Veo.`
