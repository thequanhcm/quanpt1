# ChatGPT / OpenAI usage

Use the root `SKILL.md` as the canonical instruction file.

Recommended invocation:
`@ai-video-production-director <request>`

If the environment supports custom skills/agents, install the whole folder and expose the skill name exactly as `ai-video-production-director`.

For file-based work, provide the source file together with the request. The skill must read source evidence before drafting.
