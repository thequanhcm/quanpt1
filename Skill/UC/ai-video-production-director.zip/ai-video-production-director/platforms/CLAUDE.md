# Claude usage

The root `SKILL.md` is intentionally compatible with an Agent Skill-style folder.

Place the `ai-video-production-director` folder in the skills location supported by your Claude environment, keeping all relative paths unchanged.

Invoke by asking Claude to use `ai-video-production-director` and attach/provide the source materials. Treat `SKILL.md` as canonical; `references/`, `templates/`, and `examples/` are progressive-disclosure resources.
