# Example behavior — IMAGE → VIDEO

Input: one image to animate.

Expected behavior:
1. Analyze and lock identity/composition/assets.
2. Define what may animate.
3. Add camera/depth/effects only when they serve the shot.
4. Define exact start and end frame.
5. If multiple clips are needed, chain end frame to next start/reference.
6. Add targeted negative constraints against drift and warping.
