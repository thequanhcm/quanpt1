# Example behavior — FILE → VIDEO

Input: PDF/PPTX/Word/report.

Expected behavior:
1. Read source before ideation.
2. Build Evidence Ledger.
3. Build Content Treatment Map.
4. Select the story; do not narrate page order.
5. Separate source-backed claims from `[ĐỀ XUẤT CỦA AI]`.
6. Build STANDARD or PRODUCTION PACKAGE based on complexity.
7. Put exact data/text overlays in post when reliability matters.
8. Validate duration, voice and continuity.
