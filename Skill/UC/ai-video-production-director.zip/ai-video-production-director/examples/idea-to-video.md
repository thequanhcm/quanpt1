# Example behavior — IDEA → VIDEO

Input: a short idea with target duration.

Expected behavior:
1. Infer safe production assumptions.
2. State one core message.
3. Build a compact story arc.
4. Divide into scenes and generation units whose durations sum exactly.
5. Write timed voice.
6. Produce prompts with start/end frames.
7. Run QC.

Do not invent factual claims merely to make the story stronger.
