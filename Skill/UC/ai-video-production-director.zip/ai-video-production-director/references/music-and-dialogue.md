# Music and Dialogue Direction

Read this reference for story-driven videos, character interaction or any video requiring a continuous score.

## Audio architecture

Plan four synchronized layers on one master timeline:

1. dialogue/narration
2. continuous music master or stems
3. environmental ambience
4. spot SFX and transitions

Do not design audio independently per generated clip. Assemble clips first, then carry the same music timeline across clip boundaries.

## Music Bible

Define one musical identity: theme, motif, BPM/meter, tonal character, core instruments, texture, emotional arc and forbidden drift. Use variations of the same motif for tension, warmth, discovery and resolution.

## Cue sheet

For every story beat specify absolute timecode, musical action, intensity, instrumentation change, dialogue ducking, transition and tail. Prefer stems so dialogue, rhythm and atmosphere can be balanced without replacing the track.

## Dialogue production

Create exact lines only after blocking the scene. For each line define speaker, listener, subtext, physical action, listener reaction, line duration and lip-sync approach.

Choose one approach per clip:

- `NATIVE`: generator creates the spoken line; use only when exact language and voice consistency are sufficiently reliable.
- `POST-LIPSYNC`: generate acting with clear facial visibility, record a stable character voice, then lip-sync in post.
- `OFF-SCREEN`: use narration or off-camera dialogue; no visible mouth-sync required.

Never mix approaches accidentally. Lock a Character Voice Bible and reuse voice references/settings. Prevent non-speaking characters from moving their mouths.

## Mix rules

- Duck music under speech with smooth automation, not abrupt volume jumps.
- Preserve ambience continuity with room tone across cuts.
- Let musical phrases cross visual cuts.
- Place major scene changes on musically motivated beats when possible.
- Use short SFX accents sparingly; do not compete with dialogue.
- End with a resolved music tail unless the story intentionally cuts to silence.
