# Input Analysis

## Route
Choose exactly one primary mode:
- IDEA → VIDEO
- FILE → VIDEO
- IMAGE → VIDEO
- HYBRID → VIDEO

## IDEA
Infer objective, audience, format and style only when safe. Mark consequential assumptions as `[ĐỀ XUẤT CỦA AI]`.

## FILE
Read the source faithfully. Extract messages, facts, numbers, quotes, people, dates and visualizable material. Do not narrate page-by-page unless requested.

Create a Content Treatment Map with:
`KEEP | COMPRESS | VISUALIZE | MOTION GRAPHIC | VOICE | ADD IN POST | OMIT`

## IMAGE
Analyze before prompting:
`LOCK → ANIMATE → CAMERA → DEPTH → EFFECTS → END FRAME`
Lock identity, face, clothing, architecture, composition, palette, objects, logo and source text when relevant.

## HYBRID
Treat source facts as authoritative. Label creative additions `[ĐỀ XUẤT CỦA AI]`.

## Evidence classes
- F = source-backed fact
- Q = verbatim/meaning-locked quote
- C = creative recommendation
- U = unverified; never present as fact
