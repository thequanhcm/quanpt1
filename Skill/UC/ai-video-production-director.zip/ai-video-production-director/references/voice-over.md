# Narration, Dialogue and Lip-sync Engineering

Write spoken Vietnamese naturally. Avoid reading on-screen text verbatim and avoid narrating what is already obvious visually.

Reference pacing:
- Trầm/cảm xúc: 110–130 words/minute
- Doanh nghiệp/rõ ràng: 130–150 words/minute
- Năng động: 150–165 words/minute

Estimate:
`seconds = word_count / words_per_minute × 60 + pauses`

For each scene record:
- voice text
- word count
- target duration
- expected pace
- emotion
- emphasized words
- pauses

Rewrite until timing fits.

Separate:
- GENERATION AUDIO: ambience/on-location sound if needed
- POST AUDIO: voice-over, music, SFX, mix/master

## Story dialogue

For narrative videos, separate four layers:

1. `NARRATOR`: off-screen narration.
2. `DIALOGUE`: exact words spoken by an on-screen character.
3. `REACTION`: listener response, facial beat or short vocal response.
4. `NON-VERBAL`: breath, laugh, sigh, pause, gesture or action beat.

Build a dialogue beat sheet before generation:

| Beat | Timecode | Speaker | Listener | Exact line | Emotion/subtext | Action | Listener reaction | Lip-sync method |
|---|---|---|---|---|---|---|---|---|

Rules:

- Allow only one primary speaker at a time unless overlap is intentional.
- Keep the speaker's face visible enough for lip-sync; avoid cuts across the middle of a key phrase.
- Match mouth movement duration to the recorded line, not merely the scene duration.
- Reserve reaction time after important lines.
- Maintain eyeline and screen direction between speaker and listener.
- Do not let a character speak while their established action makes speech implausible.
- Write short, speakable lines; preserve character-specific vocabulary, pace and emotion.
- If the generator cannot reliably produce exact Vietnamese speech, generate silent acting/clean ambience and add dialogue in post using separate character voices or lip-sync. State the chosen method per clip.

## Character Voice Bible

For every speaking character define: voice age, gender presentation if relevant, pitch, timbre, pace, accent/dialect only when requested, energy, emotional range, diction and forbidden drift. Reuse the same voice reference/settings across all scenes.

## Dialogue timing

Estimate each line from a character-specific speaking rate, then add reaction/action pauses. Ensure the sum of dialogue, reactions and silence fits the generation unit exactly.

## Music continuity

Create one Music Bible for the whole video:

- theme and emotional arc
- tempo/BPM range and meter
- key/mode or tonal character
- core instrumentation and sonic palette
- recurring motif
- prohibited instruments/styles
- start and ending treatment

Create a cue sheet with one continuous master track or stems. Change intensity through arrangement, not unrelated track replacement. Use beat-aligned edits, musical bridges, tails or crossfades. Duck music under narration/dialogue and restore it between lines. Never hard-reset the music at every clip boundary.
