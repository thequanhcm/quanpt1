# Visual Direction

Define a coherent visual system:
- palette
- lighting logic
- materials
- environment
- graphic language
- texture
- motion language
- density/negative space
- realism/stylization level

For data/infographic scenes, animate shapes, relationships and change. Add exact labels, numbers, names, titles, slogans and logos in post unless the user explicitly accepts generated-text risk.
