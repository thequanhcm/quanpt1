# Continuity and State Control

Create continuity records whenever a person, location or prop repeats. Treat continuity as state accounting, not descriptive resemblance.

## Bibles

### Character Bible
Record stable identity, wardrobe and body traits. Assign every character a permanent ID such as `CHAR_A`.

### Environment and Spatial Bible
Define stable landmarks and a screen-space map. Use relative anchors instead of vague prose:

- `L/C/R`: left, center, right of frame
- `FG/MG/BG`: foreground, midground, background
- named anchors: table, doorway, stove, window
- screen direction and eyeline
- camera side of the 180-degree line

Do not cross the 180-degree line unless the script shows the crossing or inserts a neutral re-establishing shot.

### Prop Bible
Assign every important prop an ID. Record appearance, owner, location, orientation, hand/contact state, condition and whether it may move.

## Blocking and Prop State Ledger

For the end of every clip, record:

| Entity | Position | Orientation/eyeline | Pose/action phase | Contact/held prop | State |
|---|---|---|---|---|---|

The next clip must initialize from this exact ledger unless an allowed transition explains the change.

## Transition Delta

Define only the permitted change between clip N and N+1:

- who moves, from where to where
- which prop moves and by whose hand
- what action continues or completes
- camera change
- lighting/time change
- emotional change

Everything not listed is locked. Never teleport a person or prop during a cut.

## Continuity Contract per clip

- previous end-state ledger
- exact start-state reconstruction
- locked entities and landmarks
- permitted Transition Delta
- screen direction and 180-degree line
- eyelines and interaction axis
- pose/action phase
- hand occupancy and prop ownership
- lighting, weather and time
- end-state ledger
- reference-frame recommendation

Prefer end frame N as the actual start/reference frame N+1. When unavailable, repeat the same state description verbatim and use the same reference images/seed controls supported by the platform.

Useful bridges: motion match; shape match; light/color bridge; eyeline/action continuation; camera-direction continuation; object handoff; first/last-frame chaining.
