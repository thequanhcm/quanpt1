# Cinematography

Specify only useful photographic choices:
- framing: ECU/CU/MCU/MS/WS/EWS
- angle: eye-level/high/low/overhead/POV
- lens character when it affects perspective
- depth of field
- camera path and speed
- subject-to-camera relationship
- foreground/midground/background separation

Replace vague adjectives with observable choices. “Cinematic” alone is insufficient; define light, composition, movement, material and rhythm.
