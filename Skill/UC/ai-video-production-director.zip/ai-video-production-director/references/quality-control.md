# Quality Control

Before final output, check and fix:
- source fidelity
- one clear core message
- hook in first 3–5 seconds when appropriate
- exact total duration
- voice fits timing
- every scene/shot has a purpose
- prompts contain temporal action
- camera has narrative reason
- continuity is consistent
- character blocking, eyelines and the 180-degree line are consistent
- prop ownership, hand occupancy, position and condition are consistent
- every clip start state equals the previous end-state ledger plus only the permitted Transition Delta
- end frames support chaining
- dialogue speaker/listener, line duration, reaction beat and lip-sync method are explicit
- non-speaking characters do not appear to speak
- one Music Bible and cue sheet sustain a coherent score without resets at clip boundaries
- music ducking leaves narration/dialogue intelligible
- safe text/data strategy
- no invented facts
- generation mode is feasible
- no contradictory instructions
- framing fits aspect ratio/platform

QC must result in corrections, not merely a defect list.
