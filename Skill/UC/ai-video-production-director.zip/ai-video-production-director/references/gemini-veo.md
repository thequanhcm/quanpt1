# Gemini / Veo Production Guidance

Optimize prompts as short generation units rather than one long undifferentiated prompt.

For each unit:
- state text-to-video, image-to-video or reference-to-video
- define the initial visual state
- describe actions in chronological order
- describe camera response
- define environmental motion
- define an intentional final frame
- preserve continuity anchors
- repeat the previous end-state ledger and allowed Transition Delta
- state speaker, exact dialogue timing and lip-sync method when characters speak

Do not claim a fixed maximum clip duration unless the user supplied it or the current tool/version has been verified. Otherwise mark `[CẦN XÁC NHẬN THEO PHIÊN BẢN CÔNG CỤ]`.

When accurate text, logo, subtitle, title or data matters, prefer `ADD IN POST`.

If voice will be produced separately, do not overload the generation prompt with exact voice delivery. Separate generation ambience from post-production voice/music/SFX.

Do not ask the model to recreate a new music track independently for every clip. Generate picture with clean ambience when practical, then lay one continuous music master/stem set across the assembled timeline. If native dialogue is requested, keep the dialogue line short, identify the sole speaker and listener, specify facial visibility and prevent other characters from moving their mouths.
