# Prompt Engineering

Default video prompts to English unless the user requests another language.

Every generation unit follows:
`START FRAME → TEMPORAL ACTION → CAMERA RESPONSE → ENVIRONMENT MOTION → END FRAME`

Include:
1. duration/aspect ratio
2. generation mode
3. subject identity
4. environment
5. exact start frame
6. temporal action sequence
7. camera movement + narrative reason
8. subject movement
9. foreground/midground/background motion
10. lighting/palette
11. composition/screen direction
12. continuity anchors
13. exact end frame
14. transition handoff
15. audio intent
16. text strategy
17. relevant negative constraints

Avoid vague prompt padding. Make motion physically and visually observable.
