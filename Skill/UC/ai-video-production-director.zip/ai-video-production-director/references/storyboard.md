# Storyboard & Shot Design

Each production unit should define:
- ID / timecode / duration
- Narrative purpose
- Visual
- Subject action
- Shot/lens
- Camera
- Light/color
- Voice/audio
- Text strategy
- Transition
- Start-frame state
- End-frame state

Do not use camera motion decoratively. Tie movement to reveal, emphasis, energy, perspective or transition.
