# Storytelling

Prefer transformation over document narration.

Possible arc:
`Hook → Context → Tension → Transformation → Proof/Impact → Resolution/CTA`

Rules:
- Hook within first 3–5 seconds when appropriate.
- One central message per video.
- One narrative purpose per scene.
- One visual idea per shot.
- Do not force every beat into every video.
- Convert abstract claims into observable actions, environments, contrasts or motion.
