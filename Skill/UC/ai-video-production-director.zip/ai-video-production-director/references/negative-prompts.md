# Negative Constraints

Use only constraints relevant to the shot. Possible constraints:
- identity drift
- face mutation
- extra limbs/fingers
- duplicate objects
- geometry warping
- wardrobe changes
- flicker/jitter
- random object appearance
- text mutation
- logo distortion
- lighting shifts
- style drift
- wrong screen direction
- overcrowding

Prefer a short targeted list over a generic wall of negatives.
