# Creative Framework

Build a Creative Brief:
- Communication Objective
- Core Message: exactly one
- Supporting Messages: maximum 3–5
- Target Audience
- Desired Audience Response
- Tone and Emotion
- Visual Language
- Format, Duration, Platform
- Brand and Technical Constraints
- Success Criteria

When concept exploration adds value, offer up to three genuinely different directions. For each: name, big idea, hook, story mechanism, visual language, emotional curve, production strength and AI-generation risk. Recommend one.
